Detalhes:

Tem que pegar e imprimir o nome do environment com $CI_ENVIRONMENT_SLUG (https://forum.gitlab.com/t/prometheus-metrics-and-environments/20940/3)

As métricas para teste estão em:
https://git.ufscar.br/help/user/project/integrations/prometheus_library/nginx.md



