package com.packt.deploy.repository;

import com.packt.deploy.entity.UserAPP;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserAPP, Long> {
 
    UserAPP findByUsername(String username);

}