package com.packt.deploy.security;

import com.packt.deploy.entity.Role;
import com.packt.deploy.entity.UserAPP;
import com.packt.deploy.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PacktUserPrincipal implements UserDetails {
    private UserAPP user;

    @Autowired
    UserRoleRepository userRoleRepository;

    public PacktUserPrincipal(UserAPP user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {

        List<Role> permissions = userRoleRepository.findAllByUser(this.user).stream().
                collect(ArrayList<Role>::new, (roles, userRole) -> {
                            roles.add(userRole.getRole());
                        }, (c,d) -> {}
                );
        return permissions;
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}
