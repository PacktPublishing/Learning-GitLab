package com.packt.deploy.service;

import com.packt.deploy.entity.Role;
import com.packt.deploy.entity.UserAPP;
import com.packt.deploy.entity.UserRole;
import com.packt.deploy.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service("userRoleService")
public class UserRoleService {
    private UserRoleRepository userRoleRepository;

    @Autowired
    public UserRoleService(UserRoleRepository userRoleRepository) {
        this.userRoleRepository = userRoleRepository;
    }

    public UserRole save(UserAPP user, Role role) {
        UserRole userRole = new UserRole(user, role);
        return userRoleRepository.save(userRole);
    }

    List<Role> findAllRolesByUser(UserAPP user) {
        return userRoleRepository.findAllByUser(user).stream().map(userRole -> userRole.getRole()).collect(Collectors.toList());
    }
}
